# frozen_string_literal: true
require "minitest/autorun"
require_relative "lib/registration"
require "specproof/minitest"
SpecProof::Minitest.install!(specifications: [File.join(__dir__, "specifications/registration.rb")],
  rbs: [File.join(__dir__, "sig/project.rbs")], targets: ["Registration#eligible?"],
  output: File.join(__dir__, "reports", ENV.fetch("REPORT_NAME", "coverage.json")))
require_relative "test/registration_test"
