# frozen_string_literal: true
class Registration
 def eligible?(age:, consent: nil)
  age > 18 && consent == true
 end
end
