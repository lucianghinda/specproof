# Evaluation task

Review the supplied behavioral specification against RBS. Report any contradiction; no requirement authorizes removing declared cases to repair it.

Selected target: `Feature#enabled?`. Explicit supplied signature: `sig/project.rbs`.
