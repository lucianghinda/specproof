SpecProof.define 'Feature#enabled?' do
 input :enabled, values: [true, :unexpected]
end
