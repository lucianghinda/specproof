# Evaluation task

Use the existing RBS declaration to check and plan supported inputs. Do not duplicate its finite domain in DSL.

Selected target: `Feature#enabled?`. Explicit supplied signature: `sig/project.rbs`.
