# Evaluation task

Check and plan the selected RBS signature. Report the tool's exact limitation if it cannot represent the whole declared input type. No type narrowing is authorized.

Selected target: `Feature#enabled?`. Explicit supplied signature: `sig/project.rbs`.
