# Supplied requirements

This task concerns input domain checking/planning. No output behavior oracle is supplied. RBS return types do not establish expected output values.
