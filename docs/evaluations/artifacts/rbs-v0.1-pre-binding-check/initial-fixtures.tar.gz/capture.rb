# frozen_string_literal: true
require "open3"
require "json"
require "time"
directory, label, *command = ARGV
abort "directory, label, command required" if !directory || !label || command.empty?
start = Time.now.utc.iso8601(6)
stdout, stderr, status = Open3.capture3(*command, chdir: directory)
record = { command: command, cwd: directory, started_at: start, completed_at: Time.now.utc.iso8601(6),
  stdout: stdout, stderr: stderr, exitstatus: status.exitstatus,
  environment: ENV.to_h.select { |key, _| %w[PATH GEM_HOME GEM_PATH RUBYOPT RUBYLIB REPORT_NAME].include?(key) } }
File.write(File.join(directory, "logs", "#{label}.json"), JSON.pretty_generate(record) + "\n")
print stdout
warn stderr unless stderr.empty?
exit(status.exitstatus || 1)
