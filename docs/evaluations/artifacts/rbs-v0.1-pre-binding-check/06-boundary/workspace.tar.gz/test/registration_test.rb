# frozen_string_literal: true
require "minitest/autorun"
class RegistrationTest < Minitest::Test
  def test_supplied_examples
    registration = Registration.new
    [0, 1, 17].each { |age| refute registration.eligible?(age: age, consent: true) }
    assert registration.eligible?(age: 18, consent: true),
      "requirements.md: eligibility begins at age 18 when consent is true; SpecProof obligation f34bb1fa38998396c7ddf02a20ba326da6c30131d696dabee7e7f6acff06daa8"
    [119, 120].each { |age| assert registration.eligible?(age: age, consent: true) }
    refute registration.eligible?(age: 120)
    refute registration.eligible?(age: 120, consent: false)
  end
end
