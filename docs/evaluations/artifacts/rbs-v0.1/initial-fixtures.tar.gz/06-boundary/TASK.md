# Evaluation task

Use the fresh report to close the justified age-18 gap. Add a regression assertion from requirements first, demonstrate RED, then fix the implementation and verify a fresh passing report without changing the contract.

Selected target: `Registration#eligible?`. Explicit supplied signature: `sig/project.rbs`.
