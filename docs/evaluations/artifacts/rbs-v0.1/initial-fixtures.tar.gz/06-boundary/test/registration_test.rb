# frozen_string_literal: true
require "minitest/autorun"
class RegistrationTest < Minitest::Test
  def test_supplied_examples
    registration = Registration.new
    [0, 1, 17].each { |age| refute registration.eligible?(age: age, consent: true) }
    [119, 120].each { |age| assert registration.eligible?(age: age, consent: true) }
    refute registration.eligible?(age: 120)
    refute registration.eligible?(age: 120, consent: false)
  end
end
