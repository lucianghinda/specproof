# Evaluation task

Create only missing behavioral refinements. Age is 0..120, minor is 0...18, adult is 18..120; these partitions are exhaustive and disjoint. Consent is supplied by RBS.

Selected target: `Registration#eligible?`. Explicit supplied signature: `sig/project.rbs`.
