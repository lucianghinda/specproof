# Independent supplied behavior rule

A registration is eligible exactly when age is at least 18 and consent is true. Ages are integers 0..120. Nil and false consent deny eligibility. Age minor 0...18 and adult 18..120 cover the age domain without overlap. This rule is independent of the implementation.
