require "minitest/autorun"
require_relative "delivery"
class DeliveryTest < Minitest::Test
  def test_standard_delivery_preserves_payload
    payload = { item: "book" }
    result = Delivery.new.save(payload)
    assert_same payload, result[:payload]
    assert_equal :standard, result[:speed]
  end
end
