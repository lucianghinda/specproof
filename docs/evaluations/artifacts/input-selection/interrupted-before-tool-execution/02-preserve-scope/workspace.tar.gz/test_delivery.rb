require "minitest/autorun"
require_relative "delivery"
class DeliveryTest < Minitest::Test
  def test_standard_delivery_and_notification
    [false, true].each do |notify|
      payload = { item: "book" }
      result = Delivery.new.save(payload, notify: notify)
      assert_same payload, result[:payload]
      assert_equal :standard, result[:speed]
      assert_equal notify, result[:notified]
    end
  end
end
