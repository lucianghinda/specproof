require "minitest/autorun"
require_relative "delivery"
class DeliveryTest < Minitest::Test
  def test_standard_delivery_preserves_payload
    payload = { item: "book" }
    result = Delivery.new.save(payload)
    assert_same payload, result[:payload]
    assert_equal :standard, result[:speed]
  end

  def test_expedited_delivery_is_express_and_preserves_payload
    payload = { item: "book" }
    result = Delivery.new.save(payload, expedited: true)
    assert_same payload, result[:payload], "payload requirement at requirements.md:2"
    assert_equal :express, result[:speed],
      "obligation 3a1322e30fee046de0c08c2dd7169a4421a1ca2d6cddaceef08338d037e988c4; requirements.md:3"
  end
end
