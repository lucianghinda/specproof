require "specproof"

SpecProof.define "Delivery#save" do
  exclude_input :payload, reason: "Payload contents are outside the requested input coverage scope"
end
