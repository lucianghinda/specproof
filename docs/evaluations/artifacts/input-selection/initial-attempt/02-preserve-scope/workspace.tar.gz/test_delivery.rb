require "minitest/autorun"
require_relative "delivery"
class DeliveryTest < Minitest::Test
  def test_standard_delivery_and_notification
    [false, true].each do |notify|
      payload = { item: "book" }
      result = Delivery.new.save(payload, notify: notify)
      assert_same payload, result[:payload]
      assert_equal :standard, result[:speed]
      assert_equal notify, result[:notified]
    end
  end

  def test_expedited_delivery_uses_express_speed
    payload = { item: "book" }
    result = Delivery.new.save(payload, expedited: true)

    assert_equal :express, result[:speed],
      "obligation 3a1322e30fee046de0c08c2dd7169a4421a1ca2d6cddaceef08338d037e988c4; requirements.md: speed is :express when expedited is true"
  end
end
