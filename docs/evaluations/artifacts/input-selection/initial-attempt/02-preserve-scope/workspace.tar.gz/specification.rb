SpecProof.define "Delivery#save" do
  exclude_input :payload, reason: "Payload contents are outside delivery-option coverage"
  input :expedited, values: [false, true]
  input :notify, values: [false, true]
end
