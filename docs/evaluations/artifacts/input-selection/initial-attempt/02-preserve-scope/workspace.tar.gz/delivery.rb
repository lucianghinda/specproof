class Delivery
  def save(payload, expedited: false, notify: false)
    { payload: payload, speed: expedited ? :express : :standard, notified: notify }
  end
end
