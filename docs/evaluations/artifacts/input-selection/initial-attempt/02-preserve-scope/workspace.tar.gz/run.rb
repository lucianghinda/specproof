require "minitest/autorun"
require_relative "delivery"
require "specproof/minitest"
SpecProof::Minitest.install!(specifications: ["specification.rb"],
  output: "coverage.json", fail_on_missing: true)
require_relative "test_delivery"
