require "minitest/autorun"
require_relative "delivery"
class DeliveryTest < Minitest::Test
  def test_standard_delivery_and_notification
    [false, true].each do |notify|
      payload = { item: "book" }
      result = Delivery.new.save(payload, notify: notify)
      assert_same payload, result[:payload]
      assert_equal :standard, result[:speed]
      assert_equal notify, result[:notified]
    end
  end

  def test_expedited_delivery_preserves_payload_and_notification
    [false, true].each do |notify|
      payload = { item: "book" }
      result = Delivery.new.save(payload, expedited: true, notify: notify)

      assert_same payload, result[:payload], "requirements.md:2 payload is returned unchanged"
      assert_equal :express, result[:speed],
        "obligation 3a1322e30fee046de0c08c2dd7169a4421a1ca2d6cddaceef08338d037e988c4; requirements.md:3 expedited true requires express"
      assert_equal notify, result[:notified], "requirements.md:4 notified equals effective notify"
    end
  end
end
