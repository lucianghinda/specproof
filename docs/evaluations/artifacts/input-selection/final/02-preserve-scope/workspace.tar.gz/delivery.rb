class Delivery
  def save(payload, expedited: false, notify: false)
    { payload: payload, speed: :standard, notified: notify }
  end
end
