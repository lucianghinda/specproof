Use the exported specproof-specify and specproof-test-gaps skills under skills/.
I explicitly want to measure only expedited=false and expedited=true for Delivery#save,
leaving payload contents outside this input-coverage scope. Use the supplied RBS signature
and independent requirements.md. Write specification.rb, check and plan it, run the
ordinary Hash-based tests, and close any justified gap with meaningful assertions.
Preserve the signature, implementation and existing assertions. Avoid duplicating RBS
finite input declarations. Report exactly what fresh evidence establishes and excludes.

Use the supplied Ruby capture.rb helper for every SpecProof/test command so actual
stdout, stderr and exit statuses are retained. Example: ruby capture.rb tool check
specification.rb --rbs sig/delivery.rbs --target 'Delivery#save' --format json.
Run ruby capture.rb test in a fresh process after edits. Write your outcome to RESULT.md.
