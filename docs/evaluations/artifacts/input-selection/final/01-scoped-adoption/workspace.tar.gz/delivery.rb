class Delivery
  def save(payload, expedited: false)
    { payload: payload, speed: expedited ? :express : :standard }
  end
end
