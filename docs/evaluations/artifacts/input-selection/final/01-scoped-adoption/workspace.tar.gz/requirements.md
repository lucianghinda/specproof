# Delivery rules
A saved Hash payload must be returned under :payload unchanged.
The :speed is :express exactly when expedited is true, otherwise :standard.
The :notified value equals the effective notify boolean when that input exists.
These are independent scenario requirements supplied for this evaluation.
