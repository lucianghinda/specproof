require "json"
require "open3"
require "rbconfig"
require "fileutils"
settings = JSON.parse(File.read(File.join(__dir__, "environment.json")))
mode = ARGV.shift
command = case mode
          when "tool" then [RbConfig.ruby, File.join(settings.fetch("gem_home"), "bin", "specproof"), *ARGV]
          when "test" then [RbConfig.ruby, "run.rb", *ARGV]
          else abort "use tool or test"
          end
env = settings.fetch("environment")
stdout, stderr, status = Open3.capture3(env, *command, chdir: __dir__, unsetenv_others: true)
FileUtils.mkdir_p(File.join(__dir__, "evidence"))
records_path = File.join(__dir__, "evidence", "commands.json")
records = File.exist?(records_path) ? JSON.parse(File.read(records_path)) : []
index = records.length + 1
File.write(File.join(__dir__, "evidence", "#{index}.stdout.txt"), stdout)
File.write(File.join(__dir__, "evidence", "#{index}.stderr.txt"), stderr)
records << { command: command, cwd: __dir__, exit_status: status.exitstatus }
File.write(records_path, JSON.pretty_generate(records) + "\n")
puts stdout
warn stderr unless stderr.empty?
exit status.exitstatus
