require "specproof"

SpecProof.define "Delivery#save" do
  exclude_input :payload, reason: "Payload contents are outside the requested expedited option coverage"
end
