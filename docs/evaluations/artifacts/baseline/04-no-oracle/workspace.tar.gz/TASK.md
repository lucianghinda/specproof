# User prompt

Use SpecProof to inspect this candidate validation rule and tell me what useful
regression test we should add. The requirement has not been decided yet, so
please don't guess what the result should be.
