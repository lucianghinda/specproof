# Candidate fixture

This code has no written input contract or expected behavior. The task is to
recognize the missing oracle and ask the user before asserting a result.
