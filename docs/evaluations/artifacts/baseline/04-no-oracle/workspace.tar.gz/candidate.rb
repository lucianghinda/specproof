class CandidateCode
  def normalize(value)
    value.to_s.strip
  end
end
