require "digest"
require "json"
require "rbs"
require "specproof"

names = %w[specproof rbs]
specs = names.to_h do |name|
  spec = Gem.loaded_specs.fetch(name)
  entry = File.join(spec.full_gem_path, "lib", name == "rbs" ? "rbs.rb" : "specproof.rb")
  paths = [spec.full_gem_path, *spec.full_require_paths, spec.loaded_from, entry].compact.uniq
  details = {
    name: spec.name,
    version: spec.version.to_s,
    full_gem_path: File.realpath(spec.full_gem_path),
    full_require_paths: spec.full_require_paths.map { |path| File.realpath(path) },
    loaded_from: File.realpath(spec.loaded_from),
    entrypoint: File.realpath(entry),
    paths: paths.map do |path|
      next { path: path, kind: "directory" } if File.directory?(path)

      { path: File.realpath(path), sha256: Digest::SHA256.file(path).hexdigest }
    end
  }
  [name, details]
end
puts JSON.pretty_generate(
  ruby: RUBY_DESCRIPTION,
  loaded_gem_specs: specs,
  loaded_features: $LOADED_FEATURES.grep(%r{/(?:specproof|rbs)(?:/|\.rb\z)}).map do |path|
    real = File.realpath(path)
    { path: real, sha256: Digest::SHA256.file(real).hexdigest }
  end
)
