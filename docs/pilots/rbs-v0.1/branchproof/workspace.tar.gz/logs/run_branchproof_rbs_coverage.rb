require "digest"
require "json"

$LOAD_PATH.unshift(File.expand_path("../project/lib", __dir__))
require "branchproof"
require "branchproof/comparison_report"
require "specproof/minitest"

target = "Branchproof::ComparisonReport#exit_code"
rbs_path = "project/sig/branchproof.rbs"
test_path = "project/test/test_comparison_report.rb"
output_path = "reports/rbs-runtime-coverage.json"

SpecProof::Minitest.install!(
  specifications: [],
  rbs: [rbs_path],
  targets: [target],
  output: output_path,
  fail_on_missing: false
)

at_exit do
  report_path = File.expand_path(output_path)
  report = JSON.parse(File.read(report_path)) if File.file?(report_path)
  package_details = %w[specproof rbs minitest].filter_map do |name|
    spec = Gem.loaded_specs[name]
    next unless spec

    entry_name = { "specproof" => "specproof.rb", "rbs" => "rbs.rb", "minitest" => "minitest.rb" }.fetch(name)
    entry_path = File.join(spec.full_gem_path, "lib", entry_name)
    {
      name: spec.name,
      version: spec.version.to_s,
      full_gem_path: File.realpath(spec.full_gem_path),
      full_require_paths: spec.full_require_paths.map { |path| File.realpath(path) },
      loaded_from: File.realpath(spec.loaded_from),
      loaded_from_sha256: Digest::SHA256.file(spec.loaded_from).hexdigest,
      entrypoint: File.realpath(entry_path),
      entrypoint_sha256: Digest::SHA256.file(entry_path).hexdigest
    }
  end
  source_manifest = JSON.parse(File.read("source-manifest.json"))
  hash_matches = source_manifest.fetch("files").all? do |relative, expected|
    copied_path = File.join("project", relative)
    File.file?(copied_path) && Digest::SHA256.file(copied_path).hexdigest == expected
  end
  metadata = {
    ruby: RUBY_DESCRIPTION,
    run_id: report&.fetch("run_id", nil),
    original_test_scope: {
      path: test_path,
      full_suite: false,
      note: "unchanged focused project test file; baseline was 2 tests and 8 assertions"
    },
    collector_target_scope: {
      target: target,
      specifications: [],
      rbs: [File.realpath(rbs_path)],
      planned_obligations: report&.fetch("obligation_count", nil)
    },
    pre_install_target_require: "branchproof/comparison_report",
    loaded_package_evidence: package_details,
    source_snapshot: {
      commit: source_manifest.fetch("commit"),
      file_count: source_manifest.fetch("files").size,
      copied_files_match_manifest: hash_matches
    },
    coverage_summary: report && report.slice(
      "schema_version", "specproof_version", "kind", "contract_digest", "completion",
      "integrity", "tests_passed", "obligation_count", "exercised_count", "missing_count",
      "unknown_count", "outside_domain", "incomplete_reasons", "errors", "scope", "obligations"
    )
  }
  File.write("reports/rbs-runtime-environment.json", JSON.pretty_generate(metadata) + "\n")
rescue StandardError => error
  warn "runtime evidence metadata failed: #{error.class}: #{error.message}"
  raise
end

load File.expand_path("../project/test/test_comparison_report.rb", __dir__)
