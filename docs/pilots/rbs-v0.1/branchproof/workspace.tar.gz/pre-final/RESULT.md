# BranchProof RBS adoption pilot

## Finding

The existing RBS signature for `Branchproof::ComparisonReport#exit_code` is sufficient for SpecProof's finite-input analysis. `fail_on_regression` is an optional keyword with type `bool`; the RBS-only plan yields the existing boolean values `false` and `true` without a DSL specification or any inferred behavioral refinement. Both values were observed in the unchanged focused Minitest run.

This evidence covers only `project/test/test_comparison_report.rb` (the existing 2-test, 8-assertion file), not the complete BranchProof suite. No test was added, no behavior gap was manufactured, and the evidence does not support a general agent-reliability claim.

## Verification

- Source: BranchProof commit `85611af97461d1714bffffff42a4719952b9cbc4`. All 59 manifest file hashes still match the unchanged pilot copy and original project checkout; the original checkout is clean.
- Signature: `project/sig/branchproof.rbs:355` — `def exit_code: (?fail_on_regression: bool) -> Integer`. The return type is not analyzed.
- `check` and `plan` both exited 0 with empty errors/findings and matching digest `d0f6f2f3dda709bfeba00b3b10e458e62995ee24a0e1f716b14024e3f110fc10`. Plan IDs and values:
  - `2c391c03cf1537c94e21d7936bde6066e1d637524e0fc2c915e743210eb94258` — `fail_on_regression: false`
  - `1a4851e3489c5ee8800a578a0ab1d4697ac4e692d5215c5ebc667f9040fa446b` — `fail_on_regression: true`
- Existing normative assertions remain in `project/test/test_comparison_report.rb:27-28`: true produces exit code 1, while the default false value produces 0. The incomplete-comparison assertion at line 32 preserves exit code 2.
- Fresh runtime report `c4d469db-9ff2-4130-9cbc-7adda999a71f` is completed, has intact integrity, and records `tests_passed: true`, 2/2 exercised obligations, zero missing/unknown/outside-domain values, and no errors or incomplete reasons. Runtime IDs match plan IDs; hits are false=2 and true=1.
- Runtime scope is exactly `Branchproof::ComparisonReport#exit_code`; `declaration_sources` contains `specifications: []`, the one canonical RBS path, and that one target. Runtime `arguments` is empty and `filter`/`exclude` are null. The runner script manually loads only `project/test/test_comparison_report.rb`; report scope alone does not prove test-file loading.
- The focused baseline and runtime each passed 2 tests and 8 assertions. See `logs/baseline-comparison-report.log` and `logs/rbs-runtime-run.log`; no full-suite command was run.

## Reproduction

From the pilot root, use Ruby 4.0.1 and the pilot's normal Bundler environment with `SPECPROOF_ROOT` set to the live SpecProof worktree:

```sh
ruby -S bundle exec ruby -Iproject/test logs/run_branchproof_rbs_coverage.rb
```

The runner explicitly requires `branchproof/comparison_report` before installing the adapter, uses `specifications: []`, supplies the original RBS file/target, and loads only the existing focused test file. Full invocation environment and output are retained in `logs/rbs-runtime-run.log`.

Offline command/output logs and parsed reports are `logs/rbs-check.log`, `logs/rbs-plan.log`, `reports/rbs-check.json`, and `reports/rbs-plan.json`. Runtime report and execution environment are `reports/rbs-runtime-coverage.json` and `reports/rbs-runtime-environment.json`.

## Skill provenance

`specproof-specify` and `specproof-test-gaps`, including their `references/usage.md`, were copied from the skills exported from the installed SpecProof 0.1.0 package. The four copied skill asset hashes match the installed package and the export manifest. The package's 17 `lib/` files also match the evaluated installed package and live worktree. Provenance and file hashes are recorded in `skill-and-package-manifest.json`; the agent-evaluation inputs are `/private/tmp/specproof-rbs-agent-evaluations/installed-package.json` and `runtime-probe.json`.

## Limits

The coverage report records effective bound values; `argument_presence` is `not_observed`, so the false hit does not establish whether the optional keyword was omitted or explicitly passed as false. RBS provides no expected output rule. Expected return codes here are supported by the existing assertions only. This pilot reports input exercise, not method correctness or complete project coverage.
