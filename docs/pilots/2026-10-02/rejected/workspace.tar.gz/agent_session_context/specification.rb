# Preserve the actual class-method identity; do not invent an instance-method adapter.
SpecProof.define "Agent::SessionContext::SemanticCategories.lookup" do
  input :identifier, values: %i[goal decision term constraint open_question next_action]
end
