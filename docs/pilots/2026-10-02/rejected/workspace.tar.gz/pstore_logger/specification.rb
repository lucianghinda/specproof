# Signature probe only; this finite scalar scenario subset is not the full PStore data domain.
SpecProof.define "PStoreLogger#save" do
  input :data, values: [nil, true, false]
  input :file_id, values: [nil]
end
