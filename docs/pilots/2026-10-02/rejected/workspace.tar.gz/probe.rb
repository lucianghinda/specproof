require "json"
require "specproof"
require "specproof/collector"
require_relative "pstore_logger/lib/pstore/logger"
require_relative "agent_session_context/lib/agent/session_context/semantic_categories"

signature = PStoreLogger.instance_method(:save).parameters
specifications = SpecProof.load([File.join(__dir__, "pstore_logger/specification.rb")])
obligations = SpecProof.plan(specifications)
coverage = SpecProof::Coverage.new(specifications: specifications, obligations: obligations)
collector = SpecProof::Collector.new(specifications: specifications, observer: coverage)
begin
  collector.start
  abort "optional keyword unexpectedly accepted"
rescue SpecProof::ConfigurationError => error
  raise unless error.code == "unsupported_parameters"

  result = {target: "PStoreLogger#save", parameters: signature, code: error.code, message: error.message, collected: false}
  File.write(File.join(__dir__, "pstore_logger/binding.json"), JSON.pretty_generate(result) + "\n")
ensure
  collector.stop
end
method = Agent::SessionContext::SemanticCategories.method(:lookup)
puts JSON.generate({target: "Agent::SessionContext::SemanticCategories.lookup", parameters: method.parameters, source_location: method.source_location})
