# frozen_string_literal: true

require "minitest/autorun"
require "tmpdir"
require "quality_gate"

module QualityGate
  class ConfigFetchAddedTest < Minitest::Test
    def test_fetch_returns_each_shipped_default
      defaults = Config.defaults
      obligation_ids = {
        adapters: "6c51acfaf3ca93069569eeac2b312528afa6f9fe4b48030f866077f9e1831c06",
        commands: "bd8c3a6a72d16acf15e05fb38f1062329ac39288b109ba2a5ac6de53b887e9eb",
        compare_point: "a144c31c5998d837a2872c927af4ba4094a8c0a50edb3390d61ade92a828c8fe",
        coverage: "ba01d4cdd7b2e022b04ed4b9efcfd5b122d0effe246f29f7bc03e6b4078b270a",
        files: "8a6f0c87ec68c1903e6fef24bd5e7ef017dedbc57e64865b83aa0c8bb02c0d83",
        format: "0c4f97c395bc63e780baa09b986aabd2adcbe41d39caac63bbda907d15098054",
        rubocop_config: "0636ff11a001c0b50b611149711b4959dcd5a728c490f06b9638412e467ddd16",
        timeouts: "4886e8f1a023a7286e748c0faf745a2dc8edf95f370c39cd510992c83d7da974"
      }

      Dir.mktmpdir do |dir|
        config = Config.load(dir: dir)

        defaults.each_key do |key|
          message = "SpecProof obligation #{obligation_ids.fetch(key)} for #{key.inspect}: " \
            "ConfigTest#test_absent_file_uses_defaults asserts Config.defaults == config.to_h " \
            "(project/test/quality_gate/config_test.rb:12)"
          if defaults.fetch(key).nil?
            assert_nil config.fetch(key), message
          else
            assert_equal defaults.fetch(key), config.fetch(key), message
          end
        end
      end
    end
  end
end
