# frozen_string_literal: true

require "digest"
require "json"

manifest = JSON.parse(File.read(File.join(__dir__, "source-manifest.json")))
root = File.join(__dir__, "project")
changed = manifest.fetch("files").filter_map do |relative_path, expected_digest|
  path = File.join(root, relative_path)
  actual_digest = Digest::SHA256.file(path).hexdigest
  relative_path unless actual_digest == expected_digest
end

abort "Source manifest mismatch: #{changed.join(', ')}" unless changed.empty?

puts "Verified #{manifest.fetch('files').length} source files against #{manifest.fetch('commit')}"
