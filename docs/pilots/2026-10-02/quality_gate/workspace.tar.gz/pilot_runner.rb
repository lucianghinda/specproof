# frozen_string_literal: true

project = ENV.fetch("PILOT_PROJECT_ROOT")
specification = ENV.fetch("PILOT_SPECIFICATION")
report = ENV.fetch("PILOT_REPORT")

$LOAD_PATH.unshift(File.join(project, "test"))
require File.join(project, "test/test_helper")
require File.join(project, "test/quality_gate/config_test")

if ENV["PILOT_ADDED"] == "1"
  require File.expand_path("config_fetch_added_test", __dir__)
end

if ENV["PILOT_ADAPTER"] == "1"
  require "specproof/minitest"
  SpecProof::Minitest.install!(
    specifications: [specification],
    output: report,
    fail_on_missing: false
  )
end
