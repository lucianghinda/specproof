Pilot QualityGate::Config#fetch(key) on the copied, unchanged source and
existing project/test/quality_gate/config_test.rb suite. Original project
has not been modified. Full project suite is out of scope for this focused
pilot. Do not install extra dependencies or change production code.

Contract scope: all eight shipped Config.defaults symbol keys. This is a
finite positive-input scope, not a claim about arbitrary Ruby Hash keys or
invalid configuration keys. Defaults and independent existing assertions
supply the oracles. Preserve every obligation and source file.

Use actual exported specproof-specify and specproof-test-gaps skills.
First check/plan, then execute unchanged config tests with adapter and
capture baseline evidence. Identify unexercised keys. Add meaningful
independent assertions grounded in existing default settings/behavior.
Run a fresh full focused suite and compare IDs/digest/run IDs. Do not claim
a production defect from unexercised inputs. No fabricated oracle or policy.

Ruby: /Users/luciang/.rubies/ruby-4.0.1/bin/ruby
SPECPROOF_ROOT=/Users/luciang/Dropbox/workprojects/opensource/specproof/gems/specproof
Use ordinary bundle with global published Minitest 5.26.2, no alternate
GEM_HOME, source rebuild, or version-constant patch. MT_NO_PLUGINS=1.
Store runner, specification, new test separately outside project/.
Retain original tests verbatim; allow only pilot-owned added files.
