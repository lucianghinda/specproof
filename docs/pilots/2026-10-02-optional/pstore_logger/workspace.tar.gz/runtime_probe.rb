# frozen_string_literal: true

require "digest"
require "json"
require "pathname"
require "rubygems"

require_relative "project/test/test_helper"
require "specproof/minitest"

spec = Gem.loaded_specs.fetch("specproof")
root = File.realpath(spec.full_gem_path)
features = $LOADED_FEATURES.filter_map do |feature|
  path = File.expand_path(feature)
  next unless path.start_with?(root + File::SEPARATOR)

  {
    loaded_feature: feature,
    absolute_path: path,
    real_path: File.realpath(path),
    sha256: Digest::SHA256.file(path).hexdigest
  }
end

requested_features = %w[specproof.rb specproof/minitest.rb]
resolutions = requested_features.to_h do |feature|
  matches = $LOAD_PATH.filter_map do |entry|
    candidate = File.expand_path(feature, entry)
    next unless File.file?(candidate)

    { load_path: entry, candidate: candidate, real_path: File.realpath(candidate), sha256: Digest::SHA256.file(candidate).hexdigest }
  end
  [feature, matches]
end

probe = {
  cwd: Dir.pwd,
  ruby_version: RUBY_DESCRIPTION,
  environment: %w[SPECPROOF_ROOT BUNDLE_GEMFILE BUNDLE_PATH GEM_HOME GEM_PATH].to_h { |name| [name, ENV[name]] },
  loaded_gem: {
    name: spec.name,
    version: spec.version.to_s,
    full_gem_path: spec.full_gem_path,
    real_gem_path: root,
    loaded_from: spec.loaded_from,
    full_require_paths: spec.full_require_paths
  },
  requested_feature_resolutions: resolutions,
  actual_loaded_features: features
}

output = File.join(__dir__, "evidence/runtime_probe.json")
File.write(output, JSON.pretty_generate(probe) + "\n")
puts output
