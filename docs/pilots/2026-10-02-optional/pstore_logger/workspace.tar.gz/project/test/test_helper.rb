# frozen_string_literal: true

require 'minitest/autorun'
require_relative '../lib/pstore/logger'
